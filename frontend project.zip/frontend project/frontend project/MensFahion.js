document.getElementById("Snitch-Shirt").onclick = function() {
    alert("SNITCH Knitted Shirt with Short Sleeves");
    window.location.href = "https://ajiio.co/HC16YL";
};
document.getElementById("uspolo_Shoes").onclick = function() {
    alert("U.S. Polo Assn. Men White Clarkin Sneakers");
    window.location.href = "https://myntr.in/0d6G7G";
};
document.getElementById("amazonPant").onclick = function() {
    alert("Lymio Men Cargo || Men Cargo Pants || Men Cargo Pants Cotton || Cargos for Men (Cargo-09-12)");
    window.location.href = "https://www.amazon.in/Lymio-Cargo-Cotton-Cargos-Cargo-09-12/dp/B0CTQBFHMH/ref=sr_1_5?crid=38RDHE3DCW42Y&dib=eyJ2IjoiMSJ9.tNyNmWsJ37dTTOhzEH3z_G14HbUicsNS21rlzDPr833a8MYx1UKTX59SyvUwcMruSH51I3KicGP7DwTIEAfSNgKgeKl_eG3ilQp9oSQKwaVsC0em_GiSC2ZWvmDSInCgY3hiF42CRFUi0NdpJx5Cc4CAu_9RKvS999FKsAV0Wlxy1UooQ_zxy5wAxl_dI4owPv3NazSEG06SePgXTmm_S8OPqSv8RVdJg_jRnjI1jGrYiZ_xkTor1TbRIa-tAU1J5MHB40xBVapPnde2gMVz0WDKyjs5tMTJPsp2QAeDq2E.hFhf8cYMXlZL6wOdf-cyuI8OjzBHOO-qX3Eb7LqTSgg&dib_tag=se&keywords=mens%2Bfashion&qid=1711548595&sprefix=mens%2Bfashio%2Caps%2C318&sr=8-5&th=1&psc=1&tag=narasimhagupt-21";
};
document.getElementById("mens_necklace").onclick = function() {
    alert("Men And Women Black Onyx Octagon Inlay Square Pendant Amulet Silver Agate Stainless Steel Pendant");
    window.location.href = "https://fkrt.co/AFO35C";
};
document.getElementById("watchInAjio").onclick = function() {
    alert("FRENCH CONNECTION F7-C Square Dial Smart Watch");
    window.location.href = "https://ajiio.co/8ikIof";
};
document.getElementById("black_cap").onclick = function() {
    alert("PUMA Men ESS Running Cap");
    window.location.href = "https://ajiio.co/CKKtsg";
};
document.getElementById("wallet").onclick = function() {
    alert("VAN HEUSEN Men Bi-Folds Wallet");
    window.location.href = "https://ajiio.co/wgq8JU";
};
document.getElementById("perfume").onclick = function() {
    alert("Ustraa Base Camp Cologne - 100 ml - Perfume for Men | Cool, Crisp Fragrance of the Mountains");
    window.location.href = "https://www.amazon.in/Ustraa-Cologne-Spray-Base-125ml/dp/B071KPL6MR/ref=sr_1_8?crid=N1ZBC837RA3N&dib=eyJ2IjoiMSJ9.F-apnObAspkNg9ooCe9twYGTWU5VaK89n7eJ0j1y10P_bTXhyx0ErizO3qdDSlDObIMmKOZoLB6K5Tfhy64qtWDh2Oo1N1SVDLzyZlxfaDrPwPCwUC145a8SCEIsJ6ZjXD-YoHqn3HVtJ7k3G-8MRTViBob0vEg8bL-J9ozoC1wXAjv7oAQ96INeZtDxuylfNQjLKI_kyI9DDoRFfiR9_04_GryhevGHES6CL09pN_uX_7PqbSgDyZpic0qkLbH9lS8w5HyG6zT43KBo_2_hVt-GqeE8-tdwdeuqLO5M77Q.5YmPsHY6UiR7ILMqIrBbsRoksltRv0yrO9DHBbzLAcE&dib_tag=se&keywords=perfumes%2Bfor%2Bmen&qid=1711562556&sprefix=perfumes%2B%2Caps%2C356&sr=8-8&th=1&tag=narasimhagupt-21";
};
document.getElementById("bracelet").onclick = function() {
    alert("FASHION FRILL Stainless Steel Link Bracelet");
    window.location.href = "https://ajiio.co/mi4csU";
};
document.getElementById("sweatshirts").onclick = function() {
    alert("Roadster Men Solid Hooded Sweatshirt");
    window.location.href = "https://myntr.in/Dm8S7i";
};
document.getElementById("parkavenue").onclick = function() {
    alert("Park Avenue Voyage & Neo Signature Collection | Deodorant for Men | Fresh Long-lasting Aroma | 150ml each (Pack of 3)");
    window.location.href = "https://www.amazon.in/Park-Avenue-Super-Saver-Voyage/dp/B00ZC4U2NY/ref=sxin_15_pa_sp_search_thematic_sspa?content-id=amzn1.sym.37bad8da-0499-4510-838e-af217f0a67c4%3Aamzn1.sym.37bad8da-0499-4510-838e-af217f0a67c4&crid=F6VDFSD6WZB9&cv_ct_cx=body%2Bspray%2Bfor%2Bmen&dib=eyJ2IjoiMSJ9.7ngqza3jx6pLmjPGgNMD9zk6jlRJvgrEzv49EvtrHihHvMTSTNR4237aja7pQadmpTZ2_pbVAZVAi-HHP2IV5g.hRFSHH6mLwOMVaQC4tcvRcBCpsjpTa_OYCq2KMUSSOY&dib_tag=se&keywords=body%2Bspray%2Bfor%2Bmen&pd_rd_i=B00ZC4U2NY&pd_rd_r=7cf9b9d1-4677-4b44-a1f6-dba4277a05ab&pd_rd_w=cfpxm&pd_rd_wg=udaM9&pf_rd_p=37bad8da-0499-4510-838e-af217f0a67c4&pf_rd_r=30BBPAZQ547XJ79MK8WC&qid=1711563214&sbo=RZvfv%2F%2FHxDF%2BO5021pAnSA%3D%3D&sprefix=body%2B%2Caps%2C317&sr=1-2-ced4eeeb-b190-41d6-902a-1ecb3fb8b7c4-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9zZWFyY2hfdGhlbWF0aWM&th=1&tag=narasimhagupt-21";
};
document.getElementById("sunscreen").onclick = function() {
    alert("Roadster Men Solid Hooded Sweatshirt");
    window.location.href = "https://fkrt.co/YbiGkR";
};