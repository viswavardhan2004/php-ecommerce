document.getElementById("amazonButton").onclick = function() {
    alert("Apple iPhone 15 Pro Max (256 GB) - Black Titanium");
    window.location.href = "https://www.amazon.in/Apple-iPhone-Pro-Max-256/dp/B0CHWV2WYK/ref=sr_1_1_sspa?crid=1ATCR1LSNRTGU&dib=eyJ2IjoiMSJ9.HriFLm_DHEZzxI2LxlyjcDtmcuzRKXhovGSPp-3LoyY2jxaiHGLt-9jMmKFSoG5OsMu-b3yUCHXXyZ7IO5Tqwi4R7LtkO4awG1IyGiO1Z8syK8ttjI24IUOznV5wUCWKStVU8qsDu-Q3qPsZ5_7DLK_6c3DdvB-A8hWZ5khrq5NyPizAPMTVlHnBNytxm_-C3wg0fhn48jLog9AFjnAFDv9P1o2c20V99P5B6OdhAkQ.VYolsYzUD4Fi-5Hx-4Ey_HBoZKePwy5YW3lET9uf2cc&dib_tag=se&keywords=iphone+15+pro+max&qid=1710672794&sprefix=iphon%2Caps%2C287&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1&tag=narasimhagupt-21";
};
document.getElementById("bracelet").onclick = function() {
    alert("FASHION FRILL Stainless Steel Link Bracelet");
    window.location.href = "https://ajiio.co/mi4csU";
};
document.getElementById("watchInAjio").onclick = function() {
    alert("FRENCH CONNECTION F7-C Square Dial Smart Watch");
    window.location.href = "https://ajiio.co/8ikIof";
};
document.getElementById("perfume").onclick = function() {
    alert("Ustraa Base Camp Cologne - 100 ml - Perfume for Men | Cool, Crisp Fragrance of the Mountains | Long-lasting | Zingy, Aquatic Notes with Fresh Masculine Fragrance");
    window.location.href = "https://www.amazon.in/Ustraa-Cologne-Spray-Base-125ml/dp/B071KPL6MR/ref=sr_1_1_sspa?crid=CVFHFKMJPNAH&dib=eyJ2IjoiMSJ9.4HeUwBDRd7rB5fzbeD27hgVRvs2goKbeG91WnjHbTyxerXqeJ2EPhGsPirKOJd9KGFZo80L7LNcwo3tNGX8xRtdY4x7qcQnPl_0QB4rElEhge5ihaKbhHsshfJZjmlK-pF21ctsfQRnW9tTnk7Kora5b3vcqJabqNPx3MR5GlxJQIa0hpmgP2O_Z071QrsqYydeXbYDx7sJvwf5FlRUQtmUWHjOvdE10aCOuj8Qvh3DMIeppL-forYtAFi-x4lqrvne5ITQOKeloNyHsT6IUPQXt6We8Q8zdflBFbQyNJIA.GDPvdAQ3O1J8WipWncF40-b-hTa5FiS1JP4uThR1v-4&dib_tag=se&keywords=Ustraa%2BBase%2BCamp%2BCologne%2B-%2B100%2Bml%2B-%2BPerfume%2Bfor%2BMen%2B%7C%2BCool%2C%2BCrisp%2BFragrance%2Bof%2Bthe%2BMountains%2B%7C%2BLong-lasting%2B%7C%2BZingy%2C%2BAquatic%2BNotes%2Bwith%2BFresh%2BMasculine%2BFragrance&nsdOptOutParam=true&qid=1711573988&sprefix=ustraa%2Bbase%2Bcamp%2Bcologne%2B-%2B100%2Bml%2B-%2Bperfume%2Bfor%2Bmen%2Bcool%2C%2Bcrisp%2Bfragrance%2Bof%2Bthe%2Bmountains%2Blong-lasting%2Bzingy%2C%2Baquatic%2Bnotes%2Bwith%2Bfresh%2Bmasculine%2Bfragrance%2Caps%2C394&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1&tag=narasimhagupt-21";
};
document.getElementById("kettle").onclick = function() {
    alert("Pigeon 14913 Electric Kettle with Bottle  (1.5 L, Silver))");
    window.location.href = "https://fkrt.co/bGwgSt";
};
document.getElementById("wallclocks").onclick = function() {
    alert("Amazon Brand - Solimo 8-inch Plastic Wall Clock/Table Clock - Map Dial (Black Frame, Quartz Movement)");
    window.location.href = "https://www.amazon.in/Amazon-Brand-Solimo-Plastic-Movement/dp/B0CRVLVXN3/ref=sr_1_1_sspa?crid=1SPGUX5RFZ3TM&dib=eyJ2IjoiMSJ9.oLThNXbcpafRbRylVyKGF9f1S6kLRFYWsc1LgFZuY7_JEA9XHhIMCrbItrJYEP4yw741z4Z407qBux0JumCXR2119mJ6cSZ8620EIAbLQGehNi2GLFN1dRycHVy503s1gSr9mMxErvYSRk823PPoPGVVlicWOxDmdkRN-sRq71I3ozulJEuLt7J42yApSDAYOFFf62yWHx8M1EBO8vsvZSBqPrV2Yc1Ydf2nR13riJMOBxaOMCSRD0dnQAsCgGtrIPd4tARhgbeoqzRqQBqhcBTlv1vnTwQv3gi_xEfu5h0.dubTs20CAA69abtDVqUxICnjBYqFtU1cyF7jwGruxJY&dib_tag=se&keywords=wall+clock&qid=1711436608&sprefix=wall+%2Caps%2C314&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1&tag=narasimhagupt-21";
};
document.getElementById("mobilepouch").onclick = function() {
    alert("MACMERISE Mickey Glass Case for iPhone 11");
    window.location.href = "https://ajiio.co/1YtRka";
};
document.getElementById("earphones").onclick = function() {
    alert("Boult Z40 with Zen ENC Mic, 60H Battery Life, Low Latency Gaming, Made In India, 5.3 Bluetooth Headset  (Blue, In the Ear)");
    window.location.href = "https://fkrt.co/79LJVn";
};
document.getElementById("youCan").onclick = function() {
    alert("You Can  (English, Paperback, Adams George Matthew)");
    window.location.href = "https://fkrt.co/PGcPwa";
};
document.getElementById("sunscreen").onclick = function() {
    alert("The Derma Co Sunscreen - SPF 50 PA+ 1% Hyaluronic Sunscreen Aqua Gel");
    window.location.href = "https://fkrt.co/YbiGkR";
};
document.getElementById("facemask").onclick = function() {
    alert("Globus Naturals Activated Charcoal Peel off Mask For Men Enriched With Vitamin-E, Aloevera");
    window.location.href = "https://fkrt.co/2cr7e4";
}