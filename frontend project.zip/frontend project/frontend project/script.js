
document.getElementById("amazonButton").onclick = function() {
    alert("Redirecting to Amazon for Apple iPhone 15 Pro Max (256 GB) - Black Titanium");
    window.location.href = "https://www.amazon.in/Apple-iPhone-Pro-Max-256/dp/B0CHWV2WYK/ref=sr_1_1_sspa?crid=1ATCR1LSNRTGU&dib=eyJ2IjoiMSJ9.HriFLm_DHEZzxI2LxlyjcDtmcuzRKXhovGSPp-3LoyY2jxaiHGLt-9jMmKFSoG5OsMu-b3yUCHXXyZ7IO5Tqwi4R7LtkO4awG1IyGiO1Z8syK8ttjI24IUOznV5wUCWKStVU8qsDu-Q3qPsZ5_7DLK_6c3DdvB-A8hWZ5khrq5NyPizAPMTVlHnBNytxm_-C3wg0fhn48jLog9AFjnAFDv9P1o2c20V99P5B6OdhAkQ.VYolsYzUD4Fi-5Hx-4Ey_HBoZKePwy5YW3lET9uf2cc&dib_tag=se&keywords=iphone+15+pro+max&qid=1710672794&sprefix=iphon%2Caps%2C287&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1&tag=narasimhagupt-21";
};

document.getElementById("amazonButton-bluetooth").onclick = function() {
    alert("Redirecting to Amazon for boAt Rockerz 255 Pro+ Bluetooth Wireless in Ear Earphones with Upto 60 Hours Playback.");
    window.location.href = "https://www.amazon.in/boAt-255-Pro-Bluetooth-Earphones/dp/B0CKRC958Z/ref=sr_1_1?crid=1XEUIPEW2DUSU&dib=eyJ2IjoiMSJ9.r5B1gG2tUKkRq4gdv9zA3h78OujmDAxN99fNVBOqfrnSduYLokpGsNOe12DW1BM7JyBW1PVQ5KtwPN9oaG-lL8w-EoyAc-lxTpuB4-HnCKl9hhkKrDnhKpF46HMS5cQj0DdJlAR_pS_QcCHm3IRsWZGoCk3Y1qve2Svwx9B3DJDgaPgW0MqpFjlbBkyt8MDobZf_6pf2SZ5rb9CCd1pe2onTpLkODF053-ZUuko2l5Q.47OYGfjjo3uRTxeQ85-jCf7K_bdNrOgXnZnviRV_C0o&dib_tag=se&keywords=boAt+Rockerz+255+Pro%2B+Bluetooth+Wireless+in+Ear+Earphones+with+Upto+60+Hours+Playback.&nsdOptOutParam=true&qid=1710673315&sprefix=boat+rockerz+255+pro%2B+bluetooth+wireless+in+ear+earphones+with+upto+60+hours+playback.%2Caps%2C244&sr=8-1&tag=narasimhagupt-21";
};

document.getElementById("flipkart-tshirt").onclick = function() {
    alert("Redirecting to flipkart Men Printed Round Neck Pure Cotton Black T-Shirt");
    window.location.href = "https://fkrt.co/RTJXf4";
};

document.getElementById("flipkart-cycle").onclick = function() {
    alert("Redirecting to flipkart VESCO Super Girl 20T Pink Kids cycle with Balance Wheel 20 T BMX Cycle ");
    window.location.href = "https://fkrt.co/E8lG0i";
};

document.getElementById("myntra-watch").onclick = function() {
    alert("Redirecting to myntra CASIO VINTAGE Unisex Watch D131 A168WA-1WDF ");
    window.location.href = "https://myntr.in/uLCSiT";
};

document.getElementById("ajio-cargo").onclick = function() {
    alert("Redirecting to ajio Women Panel Detail Cotton Twill Oversized Cargos ");
    window.location.href = "https://ajiio.co/OTjprZ";
};

document.getElementById("flipkart-bat").onclick = function() {
    alert("Redirecting to flipkart for MRF Wooden Kashmir Poplar Willow Bat-size Full Poplar Willow Cricket Bat ");
    window.location.href = "https://fkrt.co/fIkrf6";
};

document.getElementById("myntra-kittens").onclick = function() {
    alert("Redirecting to myntra for Black Pointed Toe Textured Kitten Pumps With Bows ");
    window.location.href = "https://myntr.in/hgxCP2";
};




