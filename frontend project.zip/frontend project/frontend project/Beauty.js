document.getElementById("nivieafacewash").onclick = function() {
    alert("NIVEA Milk Delight Facewash Rose Sensitive Skin | 100.0 ml");
    window.location.href = "https://ajiio.co/PcQwLh";
}
document.getElementById("glitters.avif").onclick = function() {
    alert("Better Than Eyeshadow Palette - 00 Light & Glitter");
    window.location.href = "https://ajiio.co/ySK4ep";
}
document.getElementById("ponds").onclick = function() {
    alert("Super Light Gel Oil Free Moisturiser With Hyaluronic Acid + Vitamin E - 200 ml");
    window.location.href = "https://myntr.in/qXf4i3";
}
document.getElementById("trimmers").onclick = function() {
    alert("Beard Trimmer with Hypoallergenic Blades; Zero Trim with 0.5 Mm Precision");
    window.location.href = "https://www.amazon.in/HAVELLS-BT5100C-Rechargeable-Beard-Trimmer/dp/B07C6CSF6K/ref=sr_1_2_sspa?crid=142SC19YIV1A7&dib=eyJ2IjoiMSJ9.WLNTergh-xtxG5KtBrscdOAlLJAl6aA9wYfFXvJG_UARuyYqgbuEysqq5YzSWeXy99HUNKdXyxHoBTzfqtYXeeJTsa7TgEzSoIXoTgpG8wq_jfnCv3rPmX--ng6dMbE0gXIMzvSBD02w1WmP2tRp69nThZ3sNcuab_whIJyIQlXUJVQUVNf4BSyUWdLxPI7ZRXFIgFVaWni_nW0CJL2NumS2yRD2Wns0QH5SKwTLMm7OZz0TOHIQzcb1DjT4rnZ_Js-2J33_vyZGhF36Sc4dtrvhqdAStLTmicWjG-oR1gw.5QyzroDSJs_BrBFuzPElH0s9wkFKYr36S5aTo9jY9-w&dib_tag=se&keywords=beard%2Btrimmers&qid=1711573109&sprefix=beard%2Btrimmwe%2Caps%2C230&sr=8-2-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1&tag=narasimhagupt-21https://myntr.in/qXf4i3";
}
document.getElementById("garnierfacewash").onclick = function() {
    alert("Garnier Men Turbo Bright Double Action Face Wash, Deep Cleansing Anti Pollution Face Wash with Charcoal and Vitamin C");
    window.location.href = "https://www.amazon.in/Garnier-Power-White-Double-Action/dp/B00V4L6JC2/ref=sr_1_27?crid=1DAK7YSBG7ZOT&dib=eyJ2IjoiMSJ9.JZZsRZSN8K1sTAJUVtR4C-EXZY1RGlSa4C_LUpgI2isbXLAAzP_ovhDE8cpUWQSaEq91cdk2RMIZYtWgigA7moVL2NbMbHaJf0V288g0evo1R9ptmGXrGY8l5Vu7QGn4p9YEWF3Ch9IeMLkJzwdnys4pkG1rRZD_-k8aNIZcjQnQ8MszDu2jzSmRmRnI7Cscx9j0YMZSZ_PuighPE8aj0OMtrRvz__YFMAjT75VSoC9Nf923HnCd_r5yYqcwzm2iuxcgKz62UzYwcX1AKEIdwLf60bMBhuuKS5hwtm93sdE.2AcYU1fLCKKf50-FS_P0fP47PJD1X--UBkymg6L-qUc&dib_tag=se&keywords=men+beauty+products&qid=1711573281&sprefix=men+beauty+products%2Caps%2C216&sr=8-27&tag=narasimhagupt-21";
}
document.getElementById("braceleteforwomens").onclick = function() {
    alert("11940B Crystal-Studded Heart Bracelet");
    window.location.href = "https://ajiio.co/CIFbFF";
};
document.getElementById("facemask").onclick = function() {
    alert("Globus Naturals Activated Charcoal Peel off Mask For Men Enriched With Vitamin-E, Aloevera");
    window.location.href = "https://fkrt.co/2cr7e4";
}
document.getElementById("facemaskforwomens").onclick = function() {
    alert("Globus Naturals Activated Charcoal Peel off Mask For Men Enriched With Vitamin-E, Aloevera");
    window.location.href = "https://www.amazon.in/UrbanGabru-Charcoal-Peel-Off-Mask/dp/B0777K7BLR/ref=sr_1_30?crid=3DJIZZ92GAX7P&dib=eyJ2IjoiMSJ9.gtIwt2ASzUiDaF_nsU-4t-yfkjREye2md4FkjZsKLDZW6J_Fd3JfzIPjSay6J1J84r-krFSqFmaEOqhVLk9_YUsBABsJ2eLhJ49rcZbODZBYS41VAd2uEtiYl8pvlhON0UsCdIvg-iE7NU5rM8Nggw6fw9jY9khB65WcnwjZ_PywPwQig8dZDSvk7uesKixm6pwM8lvhta1VDW1QK4EiguBYYNFVxh-LZq-19LED3RXmF0Yg3yjP2LmVH7BTvexIOsXtb18Rm8tnfDw4cltOaM9D1loP4AGI7fLb5Vw_MqA.kW9dk0gMt2I3-8pceDQyy5CH058epJYU33nVtz0NxFs&dib_tag=se&keywords=face+mask+for+womens&qid=1711573697&sprefix=face+mask+for+womens%2Caps%2C230&sr=8-30&tag=narasimhagupt-21";
}
document.getElementById("sunglasses").onclick = function() {
    alert("Women UV Protected Lens Oversized Sunglasses - B80-79");
    window.location.href = "https://ajiio.co/bY0sdj";
};
document.getElementById("niveadeodrant").onclick = function() {
    alert("Nivea Deodorant, Fresh Flower for Women, 150ml");
    window.location.href = "https://www.amazon.in/Nivea-Fresh-Flower-Deodorant-Women/dp/B016MBF2P8/ref=sr_1_5?crid=196YCQ3301FG&dib=eyJ2IjoiMSJ9.GS507devzryd3IX3QCtqkJIbLlwBtBQkBmzM776QwclaxSK0OHeeKSIMNN-XHN1oWCBgzIoZo8ElwwmAIwPlREs15QsagN9cxAd9GAiyelMAda-x170r06SE0_CAVGWKl3O537RxPCL665gL87TaSYtIWPJC1cKvCBS24obvZmp6j4beGPSln4kO-CtgUBuoI4DFRSjVvjKUXsT7EiCd0T_vlAJ0FitkufhJ766piRInhl6zkLJ4v4MszLWPyEtBC6opjgDXHpgW1P2KcoLJ76iveqpSL4GJ9w8wqY9VPIU.78PJLA4LcfkOUJApKHQVNlvFwzBsewjILhfgGb_iuX8&dib_tag=se&keywords=branded+deodorant+for+women&qid=1711571214&sprefix=branded+womens+deo%2Caps%2C215&sr=8-5&tag=narasimhagupt-21";
};
document.getElementById("braceleteforwomens").onclick = function() {
    alert("11940B Crystal-Studded Heart Bracelet");
    window.location.href = "https://ajiio.co/CIFbFF";
};
document.getElementById("perfume").onclick = function() {
    alert("Ustraa Base Camp Cologne - 100 ml - Perfume for Men | Cool, Crisp Fragrance of the Mountains | Long-lasting | Zingy, Aquatic Notes with Fresh Masculine Fragrance");
    window.location.href = "https://www.amazon.in/Ustraa-Cologne-Spray-Base-125ml/dp/B071KPL6MR/ref=sr_1_1_sspa?crid=CVFHFKMJPNAH&dib=eyJ2IjoiMSJ9.4HeUwBDRd7rB5fzbeD27hgVRvs2goKbeG91WnjHbTyxerXqeJ2EPhGsPirKOJd9KGFZo80L7LNcwo3tNGX8xRtdY4x7qcQnPl_0QB4rElEhge5ihaKbhHsshfJZjmlK-pF21ctsfQRnW9tTnk7Kora5b3vcqJabqNPx3MR5GlxJQIa0hpmgP2O_Z071QrsqYydeXbYDx7sJvwf5FlRUQtmUWHjOvdE10aCOuj8Qvh3DMIeppL-forYtAFi-x4lqrvne5ITQOKeloNyHsT6IUPQXt6We8Q8zdflBFbQyNJIA.GDPvdAQ3O1J8WipWncF40-b-hTa5FiS1JP4uThR1v-4&dib_tag=se&keywords=Ustraa%2BBase%2BCamp%2BCologne%2B-%2B100%2Bml%2B-%2BPerfume%2Bfor%2BMen%2B%7C%2BCool%2C%2BCrisp%2BFragrance%2Bof%2Bthe%2BMountains%2B%7C%2BLong-lasting%2B%7C%2BZingy%2C%2BAquatic%2BNotes%2Bwith%2BFresh%2BMasculine%2BFragrance&nsdOptOutParam=true&qid=1711573988&sprefix=ustraa%2Bbase%2Bcamp%2Bcologne%2B-%2B100%2Bml%2B-%2Bperfume%2Bfor%2Bmen%2Bcool%2C%2Bcrisp%2Bfragrance%2Bof%2Bthe%2Bmountains%2Blong-lasting%2Bzingy%2C%2Baquatic%2Bnotes%2Bwith%2Bfresh%2Bmasculine%2Bfragrance%2Caps%2C394&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1&tag=narasimhagupt-21";
};