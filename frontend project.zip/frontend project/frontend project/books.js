document.getElementById("bhagvathGeetha").onclick = function() {
    alert("Shrimad Bhagwat Gita Yatharoop  (Hardcover, Hindi, A.C BHAKTIVEDANT SWAMI SHRILA PRABHUPAD");
    window.location.href = "https://fkrt.co/uEHXgi";
};
document.getElementById("upscBook").onclick = function() {
    alert("UPPSC-CSE Toppers Notes-General Studies (Pre & Mains) -Latest Hindi Edition  (Paperback, Hindi, ToppersNotes");
    window.location.href = "https://fkrt.co/p6UKmk";
};
document.getElementById("energizeyoumind").onclick = function() {
    alert("Energize Your Mind: Learn the Art of Mastering Your Thoughts, Feelings and Emotions");
    window.location.href = "https://www.amazon.in/Energize-Your-Mind-Mastering-Thoughts/dp/0143442287/ref=asc_df_0143442287/?hvadid=619237111659&hvpos=&hvnetw=g&hvrand=261192390109075079&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9144064&hvtargid=pla-1913796178538&psc=1&mcid=8a1eec85cf6c3b19880670be0a74821d&tag=narasimhagupt-21";
};
document.getElementById("gateBooks").onclick = function() {
    alert("Gate Electronics Engg. Papers 2021 Edition  (English, Paperback, Board RPH Editorial");
    window.location.href = "https://fkrt.co/OOqHqO";
};
document.getElementById("richdad-poordad").onclick = function() {
    alert("Rich Dad Poor Dad: 25th Anniversary Edit Paperback  (Paperback, Robert Kiyosaki)");
    window.location.href = "https://fkrt.co/dkHf0Q";
};
document.getElementById("ncert10thmaths").onclick = function() {
    alert("NCERT Mathematics Books Set Class 6 To 10 (English Medium) [Hardcover] NCERT  (Hardcover, NCERT)");
    window.location.href = "https://fkrt.co/P7TKGW";
};
document.getElementById("comedybooks").onclick = function() {
    alert("Comedy Dreams  (English, Paperback, Das Shubham)");
    window.location.href = "https://fkrt.co/sKmhKe";
};
document.getElementById("nickvijuic").onclick = function() {
    alert("Life Without Limits  (English, Paperback, Vujicic Nick)");
    window.location.href = "https://fkrt.co/NuSY9Y";
};
document.getElementById("believeinyourself").onclick = function() {
    alert("Pocket FM Believe In Yourself (Hindi Audiobook) | By Joseph Murphy | Android Devices Only | Vocational & Personal Development (Audio) Vocational & Personal Development  (Audio)");
    window.location.href = "https://fkrt.co/UM9Ux6";
};
document.getElementById("born-to-bloosm").onclick = function() {
    alert("You are Born to Blossom  (English, Paperback, Kalam Apj Abdul)");
    window.location.href = "https://fkrt.co/pexXvM";
};
document.getElementById("onedaylifewillchange").onclick = function() {
    alert("ONE DAY LIFE WILL CHANGE  (Paperback, Neelam Gupta)Be the first to Review this product");
    window.location.href = "https://fkrt.co/5INEwg";
};
document.getElementById("youCan").onclick = function() {
    alert("You Can  (English, Paperback, Adams George Matthew)");
    window.location.href = "https://fkrt.co/PGcPwa";
};