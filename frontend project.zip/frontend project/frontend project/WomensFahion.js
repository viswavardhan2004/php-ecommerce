document.getElementById("womenscap").onclick = function() {
    alert("Vintage Brand Mark Cord Cap");
    window.location.href = "https://ajiio.co/22K3X8";
};
document.getElementById("womensFashion").onclick = function() {
    alert("Women Mauve Ethnic Motifs Printed Regular Kurta with Palazzos & With Dupatta");
    window.location.href = "https://myntr.in/pTTzXX";
};
document.getElementById("womensShoes").onclick = function() {
    alert("Nike Womens WMNS Air Winflo 9 Running Shoes");
    window.location.href = "https://www.amazon.in/Nike-Womens-Winflo-Spell-Black-Wheat-Running/dp/B0BNJMJZ3Y/ref=sr_1_2?crid=37H3TT9P37KR1&dib=eyJ2IjoiMSJ9.vmtVEh8r3WtDLs3qV0WH6Cz_WU1Gklx0iNSQdStCEDmsRQio0GFoN9ImbGDCUwzjEc7B-radMdw46IN6mjHdEDVSsIX2L-pgHJe8OSkd4uKgfqPanoCnjpkJoOFQew4NsGN1Nj760iO4moBDcnd1Yfhu08k6inil5W4UBFn9eJzpEc6GaVcrlpY4n0BaIPZ7ET54EQQnhC47S_QitnHyRBesFzRjRjwfVZe66Bsn4s09aF9G4zsUTqfiwpMUigAtfgCX7lfeJ4Mjz9YmeLghDVzBUdgBXzkcTopH6UWDIiY.8gQhRsS5kzKi3LosrHaZ-I58eYygYXuGd5Hk931LZjM&dib_tag=se&keywords=branded+womens+shoes&qid=1711564732&sprefix=branded+womens+shoes%2Caps%2C224&sr=8-2&tag=narasimhagupt-21";
};
document.getElementById("hairStraighner").onclick = function() {
    alert("Ultimate Shine Hair Straightener - Black Gold | 800.0");
    window.location.href = "https://ajiio.co/K7zeEJ";
};
document.getElementById("jumka").onclick = function() {
    alert("The Pari Rhodium Plated Jumkas");
    window.location.href = "https://myntr.in/GteTEW";
};
document.getElementById("braceleteforwomens").onclick = function() {
    alert("11940B Crystal-Studded Heart Bracelet");
    window.location.href = "https://ajiio.co/CIFbFF";
};
document.getElementById("sunglasses").onclick = function() {
    alert("Women UV Protected Lens Oversized Sunglasses - B80-79");
    window.location.href = "https://ajiio.co/bY0sdj";
};
document.getElementById("niveadeodrant").onclick = function() {
    alert("Nivea Deodorant, Fresh Flower for Women, 150ml");
    window.location.href = "https://www.amazon.in/Nivea-Fresh-Flower-Deodorant-Women/dp/B016MBF2P8/ref=sr_1_5?crid=196YCQ3301FG&dib=eyJ2IjoiMSJ9.GS507devzryd3IX3QCtqkJIbLlwBtBQkBmzM776QwclaxSK0OHeeKSIMNN-XHN1oWCBgzIoZo8ElwwmAIwPlREs15QsagN9cxAd9GAiyelMAda-x170r06SE0_CAVGWKl3O537RxPCL665gL87TaSYtIWPJC1cKvCBS24obvZmp6j4beGPSln4kO-CtgUBuoI4DFRSjVvjKUXsT7EiCd0T_vlAJ0FitkufhJ766piRInhl6zkLJ4v4MszLWPyEtBC6opjgDXHpgW1P2KcoLJ76iveqpSL4GJ9w8wqY9VPIU.78PJLA4LcfkOUJApKHQVNlvFwzBsewjILhfgGb_iuX8&dib_tag=se&keywords=branded+deodorant+for+women&qid=1711571214&sprefix=branded+womens+deo%2Caps%2C215&sr=8-5&tag=narasimhagupt-21";
};
document.getElementById("handbags").onclick = function() {
    alert("Black Women Sling Bag");
    window.location.href = "https://fkrt.co/7J3FvT";
};
document.getElementById("womensweatshirts").onclick = function() {
    alert("Status Apparels Combo Cotton Sweatshirts for Women Pack of 2 | Blessed and Friends Printed Stylish Full Sleeves Outfit");
    window.location.href = "https://www.amazon.in/Status-Apparels-Sweatshirt-W-SS-BLESS-BK-FRIEND-PK-XXL_Black-Pink_2XL/dp/B0BBTZ1PD2/ref=sr_1_9?crid=2K7UFZHOUCIPZ&dib=eyJ2IjoiMSJ9.OW1bsfMO03S7n48cGrZGohT22-C2VeWY-W1rv6IFRuFR5whJ6c1429wnaslMzXoi1Z7A71Ao54Zl7k1_Gv8SUVpFIhTHNPvKsY-UYFAfx1Qoo8rmm0sxI7HiF7L-jrP3yA5bhofz9JqOI9FBC6C7WhjnDwjOHoSDX4s6TUQVmlrTmt5M8-ob1Q6MTglZ84lywS0ctdwytCnSW-iE02wiiotaEn8wIrwD8koud_BP1SIf3UNFDyITqgPvT2GOaXT3BAyNcDGT3H2DoW85nFHmzf6MoXWhGTDuH1QXUUdrXto.3gTEjI3FDfPWw2w8lVhht-vMWwEG2cMvShIuGDC8jUE&dib_tag=se&keywords=women+sweatshirt&qid=1711571766&sprefix=women+swe%2Caps%2C258&sr=8-9&tag=narasimhagupt-21";
};
document.getElementById("perfume").onclick = function() {
    alert("Ustraa Base Camp Cologne - 100 ml - Perfume for Men | Cool, Crisp Fragrance of the Mountains | Long-lasting | Zingy, Aquatic Notes with Fresh Masculine Fragrance");
    window.location.href = "https://www.amazon.in/Ustraa-Cologne-Spray-Base-125ml/dp/B071KPL6MR/ref=sr_1_1_sspa?crid=CVFHFKMJPNAH&dib=eyJ2IjoiMSJ9.4HeUwBDRd7rB5fzbeD27hgVRvs2goKbeG91WnjHbTyxerXqeJ2EPhGsPirKOJd9KGFZo80L7LNcwo3tNGX8xRtdY4x7qcQnPl_0QB4rElEhge5ihaKbhHsshfJZjmlK-pF21ctsfQRnW9tTnk7Kora5b3vcqJabqNPx3MR5GlxJQIa0hpmgP2O_Z071QrsqYydeXbYDx7sJvwf5FlRUQtmUWHjOvdE10aCOuj8Qvh3DMIeppL-forYtAFi-x4lqrvne5ITQOKeloNyHsT6IUPQXt6We8Q8zdflBFbQyNJIA.GDPvdAQ3O1J8WipWncF40-b-hTa5FiS1JP4uThR1v-4&dib_tag=se&keywords=Ustraa%2BBase%2BCamp%2BCologne%2B-%2B100%2Bml%2B-%2BPerfume%2Bfor%2BMen%2B%7C%2BCool%2C%2BCrisp%2BFragrance%2Bof%2Bthe%2BMountains%2B%7C%2BLong-lasting%2B%7C%2BZingy%2C%2BAquatic%2BNotes%2Bwith%2BFresh%2BMasculine%2BFragrance&nsdOptOutParam=true&qid=1711573988&sprefix=ustraa%2Bbase%2Bcamp%2Bcologne%2B-%2B100%2Bml%2B-%2Bperfume%2Bfor%2Bmen%2Bcool%2C%2Bcrisp%2Bfragrance%2Bof%2Bthe%2Bmountains%2Blong-lasting%2Bzingy%2C%2Baquatic%2Bnotes%2Bwith%2Bfresh%2Bmasculine%2Bfragrance%2Caps%2C394&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1&tag=narasimhagupt-21";
};