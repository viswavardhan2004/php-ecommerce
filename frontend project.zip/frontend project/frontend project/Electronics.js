document.getElementById("amazonButton").onclick = function() {
    alert("Apple iPhone 15 Pro Max (256 GB) - Black Titanium");
    window.location.href = "https://www.amazon.in/Apple-iPhone-Pro-Max-256/dp/B0CHWV2WYK/ref=sr_1_1_sspa?crid=1ATCR1LSNRTGU&dib=eyJ2IjoiMSJ9.HriFLm_DHEZzxI2LxlyjcDtmcuzRKXhovGSPp-3LoyY2jxaiHGLt-9jMmKFSoG5OsMu-b3yUCHXXyZ7IO5Tqwi4R7LtkO4awG1IyGiO1Z8syK8ttjI24IUOznV5wUCWKStVU8qsDu-Q3qPsZ5_7DLK_6c3DdvB-A8hWZ5khrq5NyPizAPMTVlHnBNytxm_-C3wg0fhn48jLog9AFjnAFDv9P1o2c20V99P5B6OdhAkQ.VYolsYzUD4Fi-5Hx-4Ey_HBoZKePwy5YW3lET9uf2cc&dib_tag=se&keywords=iphone+15+pro+max&qid=1710672794&sprefix=iphon%2Caps%2C287&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1&tag=narasimhagupt-21";
};
document.getElementById("laptop").onclick = function() {
    alert("UPPSC-CSE Toppers Notes-General Studies (Pre & Mains) -Latest Hindi Edition  (Paperback, Hindi, ToppersNotes");
    window.location.href = "https://www.amazon.in/dp/B09VQ21TW4?tag=narasimhagupt-21";
};
document.getElementById("mobilecharger").onclick = function() {
    alert("MOGADGET Rechargeable Study Lamp, Touch Table Lamp for study room with USB Charging Study Lamp  (36 cm, 3 pocket holder)");
    window.location.href = "https://fkrt.co/5BdnPS";
};
document.getElementById("watchInAjio").onclick = function() {
    alert("FRENCH CONNECTION F7-C Square Dial Smart Watch");
    window.location.href = "https://ajiio.co/8ikIof";
};
document.getElementById("tv").onclick = function() {
    alert("LG 80 cm (32 inch) HD Ready LED Smart WebOS TV  (32LM563BPTC)");
    window.location.href = "https://fkrt.co/RdKExX";
};
document.getElementById("ncert10thmaths").onclick = function() {
    alert("NCERT Mathematics Books Set Class 6 To 10 (English Medium) [Hardcover] NCERT  (Hardcover, NCERT)");
    window.location.href = "https://fkrt.co/aZhv1E";
};
document.getElementById("cpu").onclick = function() {
    alert("Trixis Zaire-Z16 i5 4th Generation Computer Desktop PC CPU H81,8GB-DDR3 RAM Installed,1TB HDD and W10 Basic Software Installed - Black");
    window.location.href = "https://www.amazon.in/Trixis-Zaire-Z16-Generation-Computer-Installed/dp/B0CF9TC87Q/ref=sr_1_8?crid=3BBYP7L8F7MY&dib=eyJ2IjoiMSJ9.16d3yxlrwF-76jdjyXXIGfR04hShlblz1xYiB6UpELrPjKDWZwnEZ4N1TmaUGA_nvQ5XPBfSHJCwY_ZwVhl5UkOZdQZnYKdSQ1-VIwdStpw1bNpVF2xxQ3DsaPMRkuwWiLbG0kWO02WUlU66eHsU1aU7x11wlLXNrMSroHQn8QuLmSD57IexwRpqlghQO4LvdymeKXrPp9f8SwSIhNN5slQDx5iJMt4kvoab4ap7oJg.5OzJoGDOOQAsl_JarGbq1aenmc9zKoF1YY6BDAUVLRg&dib_tag=se&keywords=cpu%2Bfor%2Bdesktop%2Bcomputer&qid=1711435620&sprefix=cpu%2Caps%2C308&sr=8-8&th=1&tag=narasimhagupt-21";
};
document.getElementById("kettle").onclick = function() {
    alert("Pigeon 14913 Electric Kettle with Bottle  (1.5 L, Silver))");
    window.location.href = "https://fkrt.co/bGwgSt";
};
document.getElementById("wallclocks").onclick = function() {
    alert("Amazon Brand - Solimo 8-inch Plastic Wall Clock/Table Clock - Map Dial (Black Frame, Quartz Movement)");
    window.location.href = "https://www.amazon.in/Amazon-Brand-Solimo-Plastic-Movement/dp/B0CRVLVXN3/ref=sr_1_1_sspa?crid=1SPGUX5RFZ3TM&dib=eyJ2IjoiMSJ9.oLThNXbcpafRbRylVyKGF9f1S6kLRFYWsc1LgFZuY7_JEA9XHhIMCrbItrJYEP4yw741z4Z407qBux0JumCXR2119mJ6cSZ8620EIAbLQGehNi2GLFN1dRycHVy503s1gSr9mMxErvYSRk823PPoPGVVlicWOxDmdkRN-sRq71I3ozulJEuLt7J42yApSDAYOFFf62yWHx8M1EBO8vsvZSBqPrV2Yc1Ydf2nR13riJMOBxaOMCSRD0dnQAsCgGtrIPd4tARhgbeoqzRqQBqhcBTlv1vnTwQv3gi_xEfu5h0.dubTs20CAA69abtDVqUxICnjBYqFtU1cyF7jwGruxJY&dib_tag=se&keywords=wall+clock&qid=1711436608&sprefix=wall+%2Caps%2C314&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1&tag=narasimhagupt-21";
};
document.getElementById("mobilepouch").onclick = function() {
    alert("MACMERISE Mickey Glass Case for iPhone 11");
    window.location.href = "https://ajiio.co/1YtRka";
};
document.getElementById("earphones").onclick = function() {
    alert("Boult Z40 with Zen ENC Mic, 60H Battery Life, Low Latency Gaming, Made In India, 5.3 Bluetooth Headset  (Blue, In the Ear)");
    window.location.href = "https://fkrt.co/79LJVn";
};
document.getElementById("youCan").onclick = function() {
    alert("You Can  (English, Paperback, Adams George Matthew)");
    window.location.href = "https://fkrt.co/PGcPwa";
};





